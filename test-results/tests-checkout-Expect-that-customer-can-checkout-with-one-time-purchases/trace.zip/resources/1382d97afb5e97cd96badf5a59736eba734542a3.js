
    (function() {
      var baseURL = "https://cdn.shopify.com/shopifycloud/checkout-web/assets/";
      var scripts = ["https://cdn.shopify.com/shopifycloud/checkout-web/assets/runtime.baseline.en.f164f5236a2c74a1cb33.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/902.baseline.en.fb54bc2ba2b7a034c1fb.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/574.baseline.en.b405d25ffee7f1d9af43.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/991.baseline.en.cb2c3e7f8ee87cd9bad9.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/app.baseline.en.fa09628329d73bbcbac4.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/845.baseline.en.d590c77360b092302df2.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/953.baseline.en.df6290f0ae231ad6be80.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/18.baseline.en.17f9af0a6a6ecd3265f0.js","https://cdn.shopify.com/shopifycloud/checkout-web/assets/OnePage.baseline.en.4743d48a871640c411bf.js"];
      var styles = ["https://cdn.shopify.com/shopifycloud/checkout-web/assets/902.baseline.en.e11205b132d83ce78bf8.css","https://cdn.shopify.com/shopifycloud/checkout-web/assets/app.baseline.en.250d3210c52f65b69a28.css","https://cdn.shopify.com/shopifycloud/checkout-web/assets/268.baseline.en.3970055027214a5e7103.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = ["https://cdn.shopify.com/s/files/1/0761/6924/9081/files/Logo_Trim_1_x320.png?v=1685984148"];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = [baseURL].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res[0], next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        })();
      }

      function onLoaded() {
        preconnectAssets();
        prefetchAssets();
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  